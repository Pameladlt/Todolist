/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ToDoList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author galindo
 */
public class TaskOperation {
    
    private Integer id = 0;
    
//    Map<Integer, Task> taskMap = new HashMap<Integer, Task>();
//    Map<Integer, Task> completeTaskMap = new HashMap<Integer, Task>();

//      List getTaskList() = new ArrayList();
//      List taskCompleteList = new ArrayList();
    
      Task task;
      
    public TaskOperation(){
        
    }
    
    public void saveTask(Task task2){
//        task.add(id,task);
        task.getTaskList().add(id,task2);
        id++;
    }
    
    public void deleteTask(Task task2){
        if(task.getTaskList().isEmpty())
            System.out.println("Map is empty");
        else{
            task.getTaskList().remove(task2.getTask());
            
        }
        id--;
    }
    
    public void completeTask(Integer id, Task task2){
        if(task.getTaskList().get(id) != null)
            task.taskCompleteList.add(id, task2);
        else
            System.out.println("No task found");
    }
    
    
    //seters and getters
    
     public int getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List getTaskList() {
        return task.getTaskList();
    }

    public List getTaskListKeyValue(Integer id) {
        return (List) task.getTaskList().get(id);
    }
    public List getTaskCompleteList() {
        return task.taskCompleteList;
    }

    
    
}
