/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Integradoras;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;



/**
 *
 * @author galindo
 */

public class Persona {
    private String nombre;
    private String apellido;
    private String edad;
    
    public Persona(){
        this.nombre="";
        this.apellido="";
        this.edad="";
    }
    
    public Persona(String name, String lastName, String age){
        this.setNombre(name);
        this.setApellido(lastName);
        this.setEdad(age);
    }
    public String getNombre(){
        return this.nombre;
    }
    
    public String getApellido(){
        return this.apellido;
    }
    
    public String getEdad(){
        return this.edad;
    }
    
    public void setNombre(String name){
        this.nombre=name;
    }
    
    public void setApellido(String lastName){
        this.apellido = lastName;
    }
    
    public void setEdad(String age){
        this.edad = age;
    }
    
   
    
    
    
    
    
    
}
