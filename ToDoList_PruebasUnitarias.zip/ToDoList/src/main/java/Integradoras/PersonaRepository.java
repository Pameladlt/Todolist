/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Integradoras;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;
import Integradoras.Persona;
import java.sql.ResultSet;
/**
 *
 * @author galindo
 */

public class PersonaRepository {
    
    
    public PersonaRepository(){
    }
    
    
    public void save(Persona persona) throws SQLException{
       Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Calidad", "root", "");
       String sql = "INSERT INTO `Persona` (`nombre`, `apellido`, `edad`) VALUES ('"+persona.getNombre()+"', '"+persona.getApellido()+"', '"+persona.getEdad()+"');";
       Statement stmt = connection.createStatement();
       stmt.execute(sql);
    
    }
    
    public void delete(Persona persona) throws SQLException{
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Calidad","root","");
        String sql = "DELETE FROM `Persona` WHERE `nombre` ='"+persona.getNombre()+/*"'&& `apellido='"+persona.getApellido()+*/"';";
        Statement stmt = connection.createStatement();
        stmt.execute(sql);
    }
    
    public void update(Persona persona, String newAge) throws SQLException{
        persona.setEdad(newAge);
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Calidad","root","");
        String sql = "UPDATE `Persona` SET `edad`='"+persona.getEdad()+"' WHERE `nombre`='"+persona.getNombre()+"'&& `apellido`='"+persona.getApellido()+"';";
        Statement stmt = connection.createStatement();
        stmt.execute(sql);
    }
    
    public Persona findbyName(String nombre) throws SQLException{
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Calidad","root","");
        String sql = "SELECT * FROM `Persona` WHERE `nombre`='"+nombre+"';";
        Statement stmt = connection.createStatement();
        ResultSet rs= stmt.executeQuery(sql);
        rs.next();
        String apellido = rs.getString("apellido");
        String name = rs.getString("nombre");
        String edad = rs.getString("edad");
        Persona respuesta = new Persona(name, apellido, edad);
        return respuesta;
    }
    
}
