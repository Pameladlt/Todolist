/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TaskTest;

import ToDoList.Task;
import ToDoList.TaskOperation;
import java.util.ArrayList;
import java.util.List;
import org.dbunit.Assertion;
import org.junit.Test;
import static org.junit.Assert.*;
import org.mockito.internal.matchers.Null;

/**
 *
 * @author galindo
 */
public class testTask {
    
    public testTask() {
    }

//   
//    @Test
//    public void saveTaskTest(){
//        
//        List<Task> taskList = new ArrayList<Task>(); 
//        
//        Task task = new Task("Comer",2211,"otro","high","Emilio");
//        TaskOperation to = new TaskOperation();
//        
//        to.saveTask(task);
//        
//        assertEquals(task.getTask(),"Comer");
//        assertEquals(task.getDateDue(),2211);
//        assertEquals(task.getType(),"otro");
//        assertEquals(task.getImportance(),"high");
//        assertEquals(task.getUser(),"Emilio");
//    }
    
    @Test
    public void deleteTaskTest(){
        Task task = null;
        List<Task> taskList = new ArrayList<Task>(); 
        TaskOperation to = new TaskOperation();
        
        assertNull(task.getTaskList().isEmpty());
        
        Task taskAdd = new Task("Comer",2211,"otro","high","Emilio");
        
         to.saveTask(taskAdd);
         
         assertFalse(task.getTaskList().isEmpty());
         
         to.deleteTask(taskAdd);
        
         assertTrue(task.getTaskList().isEmpty());
    }
}
