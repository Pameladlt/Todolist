/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Testings;

import Integradoras.Persona;
import Integradoras.PersonaRepository;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.ext.mysql.MySqlDataTypeFactory;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author galindo
 */
public class testPerson {

    public JdbcDatabaseTester myDBtester;
    public testPerson() {
        
    }

    @Before
    public void setUp() {
        try {
            this.myDBtester = new JdbcDatabaseTester("com.mysql.jdbc.Driver", "jdbc:mysql://localhost:3306/Calidad", "root", "");

            //Iniciar la Base de Datos
            FlatXmlDataSetBuilder builder = new FlatXmlDataSetBuilder();

            IDataSet ds = builder.build(this.getClass().getResourceAsStream("/init.xml"));
            myDBtester.setDataSet(ds);
            myDBtester.onSetup();

        } catch (Exception ex) {
            Logger.getLogger(testPerson.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    @Test
    public void insertTest() throws SQLException, DataSetException, Exception{
        Persona persona = new Persona("Emilio","Galindo","20");
        PersonaRepository rp = new PersonaRepository();
        rp.save(persona);
        ITable actualTable = null;
        
        IDatabaseConnection connection = myDBtester.getConnection();
        
        DatabaseConfig dbconfig = connection.getConfig();
        dbconfig.setProperty("http://www.dbunit.org/properties/datatypeFactory", new MySqlDataTypeFactory());
        
        IDataSet databaseDataSet = connection.createDataSet();
        try {
          actualTable= databaseDataSet.getTable("Persona");
        } catch (DataSetException ex) {
            Logger.getLogger(testPerson.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        FlatXmlDataSetBuilder builder = new FlatXmlDataSetBuilder();
        IDataSet expectedDataSet = builder.build(this.getClass().getResourceAsStream("/expected.xml"));
        
        ITable expectedTable = expectedDataSet.getTable("Persona");
        
        Assertion.assertEquals(expectedTable, actualTable);
    }
    
//    @Test
//    public void selectTest() throws SQLException, DataSetException, Exception{
//        
//        ITable actualTable = null;
//        
//        IDatabaseConnection connection = myDBtester.getConnection();
//        
//        DatabaseConfig dbconfig = connection.getConfig();
//        dbconfig.setProperty("http://www.dbunit.org/properties/datatypeFactory", new MySqlDataTypeFactory());
//        
//        IDataSet databaseDataSet = connection.createDataSet();
//        try {
//          actualTable= databaseDataSet.getTable("Persona");
//        } catch (DataSetException ex) {
//            Logger.getLogger(testPerson.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//        String actualName = (String) actualTable.getValue(0,"nombre");
//        
//        FlatXmlDataSetBuilder builder = new FlatXmlDataSetBuilder();
//        IDataSet expectedDataSet = builder.build(this.getClass().getResourceAsStream("/init.xml"));
//        ITable expectedTable = expectedDataSet.getTable("Persona");
//        
//        String actualExpected = (String) expectedTable.getValue(0, "nombre");
//        
//        assertEquals(actualName, actualExpected);
//    }
// 
//    @Test
//    public void deleteTest() throws SQLException, DataSetException, Exception{
//        //Iniciar la Base de Datos
//            FlatXmlDataSetBuilder builder = new FlatXmlDataSetBuilder();
//            IDataSet ds = builder.build(this.getClass().getResourceAsStream("initdelete.xml"));
//            myDBtester.setDataSet(ds);
//            myDBtester.onSetup();
//        Persona persona = new Persona("Emilio","Galindo","20");
//        PersonaRepository rp = new PersonaRepository();
//        rp.delete(persona);
//        ITable actualTable = null;
//        IDatabaseConnection connection = myDBtester.getConnection();
//        DatabaseConfig dbconfig = connection.getConfig();
//        dbconfig.setProperty("http://www.dbunit.org/properties/datatypeFactory", new MySqlDataTypeFactory());
//        IDataSet databaseDataSet = connection.createDataSet();
//        try {
//            actualTable= databaseDataSet.getTable("persona");
//        } catch (DataSetException ex) {
//            Logger.getLogger(JdbcDatabaseTester.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        FlatXmlDataSetBuilder builder2 = new FlatXmlDataSetBuilder();
//        IDataSet expectedDataSet = builder2.build(this.getClass().getResourceAsStream("expected.xml"));
//        ITable expectedTable = expectedDataSet.getTable("persona");
//        Assertion.assertEquals(expectedTable, actualTable);
//    }
    
}
